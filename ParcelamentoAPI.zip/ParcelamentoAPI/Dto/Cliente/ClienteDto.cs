﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ParcelamentoAPI.Dto.Cliente
{
    public class ClienteDto
    {
        public int Id { get; set; }

        public string Nome { get; set; }

        public string TelefoneNegociacao { get; set; }

     

    }
}
